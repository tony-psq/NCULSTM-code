# -*- coding: utf-8 -*-
"""
Created on Tue Jul 24 12:55:50 2018

@author: psq
"""

from scrapy.selector import Selector
from pandas import DataFrame
import pandas as pd
from openpyxl import load_workbook

def transform(col):
    
    strs=col.split(',');
    num=-1;
    if len(strs)==1 and strs[0]!='-':
        num=float(strs);
    elif len(strs)==2:
        num=float(strs[0]+'.'+strs[1]);
    else:
        print('待处理！')
    return num;
    
    print('csa')


month='201806';


with open('./'+month+'.html','r') as fp:
    body=fp.read();
    
    rows=Selector(text=body).xpath('/html/body/tbody/tr').extract();
    contents=[];
    for row in rows:
        cols=Selector(text=row).xpath('//tr/td/text()').extract();
        
        [date, time]=cols[0].split(' ');
        
        speed=transform(cols[1]);
        
        contents.append([date,time,speed]);
        
    writer=pd.ExcelWriter('SpeedData.xlsx',engine='openpyxl');   
    book=load_workbook(writer.path);
    writer.book=book;
    contentsFrame=DataFrame(contents,columns=['date','time','speed'])
    contentsFrame.to_excel(excel_writer=writer,sheet_name=month)
    writer.save();
    writer.close();




#==============================================================================
# if __name__=='__main__':
#     a=1;
#==============================================================================
