import sys
sys.path.append('../..')

from python.DataUtils.DataUtils import DataUtils
from sklearn.svm import SVR
from pandas import DataFrame
import matplotlib.pyplot as plt

for caseNum in range(1,5):

    train,validate=DataUtils.getData(caseNum);
    
    trainX=train[['x1','x2']];
    trainY=train['Y'];
    
    validateX=validate[['x1','x2']];
    validateY=validate['Y'];
    
    svr= SVR(kernel='rbf', C=1000)#, gamma=0.1
    
    svr.fit(trainX,trainY);
    predictions=svr.predict(validateX);
    
    pre=DataFrame(predictions,columns=['均值归一']);
    
    bath='../data/result/SVRcase'+str(caseNum)+'.xls';
    pre.to_excel(bath,sheet_name='1',index=False);

    plt.plot(validateY,'-',label='observations')
    plt.plot(predictions,'-',label='predictions')

    
    plt.legend()
    
    plt.show()