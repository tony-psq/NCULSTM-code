# -*- coding: utf-8 -*-
"""
Created on Wed Jul 25 16:15:26 2018

@author: psq
"""


import xlrd
from pandas import DataFrame
import pickle


class DataUtils:
    
    # 读取excel数据
    def readExcel(path,sheetFlag):
        # 打开文件
        workbook=xlrd.open_workbook(path);

        
        # 获取工作表
        if isinstance(sheetFlag,int):
            # 通过索引获取工作表
            sheet=workbook.sheet_by_index(sheetFlag);
        else:
            # 通过名称获取工作表
            sheet=workbook.sheet_by_name(sheetFlag);
        
        # 行数
        rows=sheet.nrows;
        # 列数
        cols=sheet.ncols;
        
        data={};
        columnNameArray=[];
        for i in range(cols):
            # 表头
            columnName=sheet.cell(0,i).value;
            # 获取列数据类型
            ctype=sheet.cell(1,i).ctype;
            if ctype==3:
                #日期类型
                column=[];
                for j in range(1,rows):
                    column.append(xlrd.xldate.xldate_as_datetime(sheet.cell(j,i).value,0));
            else:
                column=sheet.col_values(i)[1::];
            data[columnName]=column;
            columnNameArray.append(columnName);
        
        df=DataFrame(data, columns=columnNameArray);
                
        return df
        
    # 持久化变量
    def pickleData(path,data):
        with open(path,'wb') as file:
            pickle.dump(data,file);
    # 加载持久化的变量            
    def loadData(path):
        with open(path,'rb') as file:
            data=pickle.load(file)
        return data

    def getData(caseNum):
        path='../data/FLcase'+str(caseNum)+'.xls';
        train=DataUtils.readExcel(path,'train');
        validate=DataUtils.readExcel(path,'validate');
        
        return train,validate;
