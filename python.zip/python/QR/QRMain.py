# -*- coding: utf-8 -*-
"""
Created on Thu Jul 26 08:59:26 2018

@author: psq
"""


import sys
sys.path.append('../..')

from python.DataUtils.DataUtils import DataUtils
import statsmodels.api as sm

from statsmodels.regression.quantile_regression import QuantReg
import statsmodels.formula.api as smf
import matplotlib.pyplot as plt
from pandas import DataFrame

#%%
for caseNum in range(1,5):

    train,validate=DataUtils.getData(caseNum);
    
    trainX=train[['x1']];#'x1','x2'
    trainY=train['Y'];
    
    validateX=validate[['x1']];
    validateY=validate['Y'];
    
    mod1=QuantReg(trainY, trainX);
    res1 = mod1.fit(q=.5, kernel='cos',max_iter=2000)
    pre1=res1.predict(validateX)
    print(res1.summary())
    print('\n\n')
    
    mod1=QuantReg(trainY, trainX);
    res1 = mod1.fit(q=.025, kernel='cos',max_iter=2000)
    down=res1.predict(validateX)
    
    
    mod1=QuantReg(trainY, trainX);
    res1 = mod1.fit(q=.975, kernel='cos',max_iter=2000)
    up=res1.predict(validateX)
    
    content=DataFrame(columns={'均值归一','标签归一','上限归一','下限归一'});#{'均值归一':pre1,'上限归一':up,'下限归一':down}
    content['均值归一']=pre1;
    content['标签归一']=validateY;
    content['上限归一']=up;
    content['下限归一']=down;
    
    bath='../data/result/QRcase'+str(caseNum)+'.xls';
    content.to_excel(bath,sheet_name='1',index=False);
    
    
    plt.plot(validateY,'-',label='observations')
    plt.plot(pre1,'-',label='predictions')
    plt.plot(down,'--',label='down')
    plt.plot(up,'--',label='up')
    
    plt.legend()
    
    plt.show()
#%%

#==============================================================================
# formula = 'Y ~ x1 + x2'
# 
# mod2 = smf.quantreg(formula=formula, data=train)
# res2 = mod2.fit(q=.5)
# 
# pre2=res2.predict(validate)
# 
# print(res2.summary())
# 
# 
# 
# 
# quant_a = res2.params[0]
# quant_b = res2.params[1]
# quant_ab = res2.params[2]
#==============================================================================

