package com.psq.model.nLstmState;

import com.psq.model.utils.Matrix;
import com.psq.model.weight.Weight;
import com.psq.model.weight.WeightHX;

public class LstmState {
	/**
	 * 重置门状态矩�?
	 */
	public Matrix[] rs;
	/**
	 * 更新门状态矩�?
	 */
	public Matrix[] zs;
	/**
	 * 状�?�更新矩�?
	 */
	public Matrix[] has;
	/**
	 * 输出状�?�矩�?
	 */
	public Matrix[] hs;
	/**
	 * 结果状�?�矩�?
	 */
	public Matrix[] ys;
	/**
	 * 时间
	 */
	int step;
	/**
	 * 次数�?
	 */
	int currentStep;
	
	public LstmState(int step, int xDim, int hiddenDim){
		this.step=step+1;
		//初始�? 五个矩阵每个时间的状态
		this.currentStep=1;
		
		//重置�?
		this.rs=new Matrix[step+1];
		for(int i=0;i<step+1;i++){
			rs[i]=new Matrix(hiddenDim,1);
		}
		
		//更新�?
		this.zs=new Matrix[step+1];
		for(int i=0;i<step+1;i++){
			zs[i]=new Matrix(hiddenDim,1);
		}
		
		//状�??
		this.has=new Matrix[step+1];
		for(int i=0;i<step+1;i++){
			has[i]=new Matrix(hiddenDim,1);
		}
		
		//输出
		this.hs=new Matrix[step+1];
		for(int i=0;i<step+1;i++){
			hs[i]=new Matrix(hiddenDim,1);
		}
		
		//结果
		this.ys=new Matrix[step];
		int yDim=1;//杩欓噷搴旇鏄緭鍑哄眰鐨勭淮搴�?
		for(int i=0;i<step;i++){
			ys[i]=new Matrix(yDim,1);
		}		
		
		
	}
	/**
	 * 向前传播
	 * @param weight
	 * @param x
	 */
	public void update(Weight weight, Matrix x){
		//产生ht-1
		Matrix preHt=this.hs[currentStep-1];
		//rs向前传播
		this.rs[currentStep]=calGate(weight.whxr,preHt,x,"sigmoid");
		//zs向前传播
		this.zs[currentStep]=calGate(weight.whxz,preHt,x,"sigmoid");
		//has向前传播
		Matrix first=weight.whxh.wh.times(rs[currentStep].arrayTimes(preHt));
		Matrix last=weight.whxh.wx.times(x.transpose());
		this.has[currentStep]=Matrix.tanh(first.plus(last).plus(weight.whxh.b));
		//ht向前传播
		this.hs[currentStep]=preHt.minus(zs[currentStep].arrayTimes(preHt)).plus(zs[currentStep].arrayTimes(has[currentStep]));
		Matrix yz=weight.wY.w.times(hs[currentStep]).plus(weight.wY.b);
		//得出预测结果y
		ys[currentStep-1]=Matrix.sigmoid(yz);
		currentStep++;
		
		
	}
	/**
	 * 璁＄畻闂ㄩ檺缁撴�?
	 * @param whx
	 * @param preHt
	 * @param x
	 * @param activation
	 * @return
	 */
	private Matrix calGate(WeightHX whx, Matrix preHt, Matrix x, String activation){
		Matrix zh=whx.wh.times(preHt);
		Matrix zx=whx.wx.times(x.transpose());
		Matrix z=zh.plus(zx).plus(whx.b);
		Matrix a=z;
		if(activation.equals("sigmoid")){
			a=Matrix.sigmoid(z);
		}else if(activation.equals("tanh")){
			a=Matrix.tanh(z);
		}else{
			throw new IllegalArgumentException("activation function not implemented!");
		}
		
		return a;
	}
	

}
