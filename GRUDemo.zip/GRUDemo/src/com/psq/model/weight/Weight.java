package com.psq.model.weight;



public class Weight {
	/**
	 * ������Ȩ��
	 */
	public WeightHX whxr;
	/**
	 * ������Ȩ�� 
	 */
	public WeightHX whxz;
	/**
	 * ״̬Ȩ��
	 */
	public WeightHX whxh;
	/**
	 * ״̬Ȩ��
	 */
	public WeightY wY;
	
	/**
	 * ���캯����ʼ��
	 * @param xDim
	 * @param hiddenDim
	 */
	public Weight(int xDim, int hiddenDim){
		this.whxr=new WeightHX(xDim, hiddenDim);
		this.whxz=new WeightHX(xDim, hiddenDim);
		this.whxh=new WeightHX(xDim, hiddenDim);
		this.wY=new WeightY(1, hiddenDim);
	}
	
	public Weight(){
		
	}
	/**
	 * ����Ȩ�ظ���
	 * @param dWeight
	 * @param lr
	 */
	public void updateHX(DWeight dWeight, double lr){
		this.whxr.update(dWeight.dwhxr, lr);
		this.whxz.update(dWeight.dwhxz, lr);
		this.whxh.update(dWeight.dwhxh, lr);
		
	}
	
	public void updateY(DWeight dWeight, double lr){
		this.wY.update(dWeight.dwY, lr);
	}
	
	public Weight clone(){
		Weight newWeight=new Weight();
		newWeight.whxr=this.whxr.clone();
		newWeight.whxz=this.whxz.clone();
		newWeight.whxh=this.whxh.clone();
		newWeight.wY=this.wY.clone();
		
		return newWeight;
	}
	

}

