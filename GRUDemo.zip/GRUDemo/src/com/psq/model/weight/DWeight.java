package com.psq.model.weight;

import com.psq.model.utils.Matrix;

public class DWeight {
	/**
	 * 涓�涓牱鏈殑鐗瑰�?
	 */
	int xDim;
	/**
	 * 闅愯棌灞傝妭鐐规�?
	 */
	int hiddenDim;
	/**
	 * dwh,dwx,db
	 */
	public DWeightHX dwhxr,dwhxz,dwhxh;
	public DWeightY dwY;
	
	public DWeight(int xDim,int hiddenDim){
		this.xDim=xDim;
		this.hiddenDim=hiddenDim;
		
		this.dwhxr=new DWeightHX(xDim, hiddenDim);
		this.dwhxz=new DWeightHX(xDim, hiddenDim);
		this.dwhxh=new DWeightHX(xDim, hiddenDim);
		
		this.dwY=new DWeightY(1,hiddenDim);
		
	}
	/**
	 * 璁＄畻鍚勪釜鏉冮噸鐭╅樀鐨勫亸�?�兼�?
	 * @param di
	 * @param df
	 * @param da
	 * @param doo
	 * @param hss
	 * @param x
	 */
	public void update(Matrix dr, Matrix dz, Matrix dh, Matrix hss, Matrix x,Matrix r){
		this.dwhxr.calGrad(dr, hss, x);
		this.dwhxz.calGrad(dz, hss, x);
		this.dwhxh.calGradh(dh, hss, x, r);
	}
	/**
	 * 鏉冮噸鍚戦噺鍙犲�?
	 * @param dWeight
	 * @return
	 */
	public DWeight add(DWeight dWeight){
		DWeight result=new DWeight(this.xDim,this.hiddenDim);
		result.dwhxr=this.dwhxr.add(dWeight.dwhxr);
		result.dwhxz=this.dwhxz.add(dWeight.dwhxz);
		result.dwhxh=this.dwhxh.add(dWeight.dwhxh);
		result.dwY=this.dwY.add(dWeight.dwY);
		
		return result;
	}

	
}

