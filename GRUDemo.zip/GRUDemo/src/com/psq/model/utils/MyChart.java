package com.psq.model.utils;

import java.awt.Color;
import java.awt.Font;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.RefineryUtilities;

public class MyChart {
    public static void drawLoss(double[] data) {
    	String applicationTitle="Figure";
    	String chartTitle="loss change figure";
    	String xLabel="iter";
    	String yLabel="loss";
    	XYSeriesCollection dataSet =new XYSeriesCollection();
    	XYSeries loss=new XYSeries("loss");
    	for(int i=0;i<data.length;i++){
    		loss.add(1.0*i, data[i]);
    	}
    	dataSet.addSeries(loss);
    	XYLineChartFrame chart=new XYLineChartFrame(applicationTitle, chartTitle, xLabel, yLabel, dataSet);
	    chart.pack( );          
	    RefineryUtilities.centerFrameOnScreen( chart );          
	    chart.setVisible( true ); 
    }
    public static void drawLoss(double[] data, int flag) {
    	String applicationTitle="Figure";
    	String chartTitle="loss change figure for "+flag;
    	String xLabel="iter";
    	String yLabel="loss";
    	XYSeriesCollection dataSet =new XYSeriesCollection();
    	XYSeries loss=new XYSeries("loss");
    	for(int i=0;i<data.length;i++){
    		loss.add(1.0*i, data[i]);
    	}
    	dataSet.addSeries(loss);
    	XYLineChartFrame chart=new XYLineChartFrame(applicationTitle, chartTitle, xLabel, yLabel, dataSet);
	    chart.pack( );          
	    RefineryUtilities.centerFrameOnScreen( chart );          
	    chart.setVisible( true ); 
    }
    public static void drawCompare(double[][] pre, double[][] y) {
    	String applicationTitle="Figure";
    	String chartTitle="compared figure";
    	String xLabel="time";
    	String yLabel="value";
    	XYSeriesCollection dataSet =new XYSeriesCollection();
    	XYSeries ySeries=new XYSeries("y");
    	XYSeries preSeries=new XYSeries("pre");
    	for(int i=0;i<pre.length;i++){
    		ySeries.add(1.0*i, y[i][0]);
    		preSeries.add(1.0*i, pre[i][0]);
    	}
    	dataSet.addSeries(ySeries);
    	dataSet.addSeries(preSeries);
    	XYLineChartFrame chart=new XYLineChartFrame(applicationTitle, chartTitle, xLabel, yLabel, dataSet);
	    chart.pack( );          
	    RefineryUtilities.centerFrameOnScreen( chart );          
	    chart.setVisible( true ); 
    }
    public static void drawCompare(double[][] pre, double[][] y, int flag) {
    	String applicationTitle="Figure";
    	String chartTitle="compared figure for "+flag;
    	String xLabel="time";
    	String yLabel="value";
    	XYSeriesCollection dataSet =new XYSeriesCollection();
    	XYSeries ySeries=new XYSeries("y");
    	XYSeries preSeries=new XYSeries("pre");
    	for(int i=0;i<y.length;i++){
    		ySeries.add(1.0*i, y[i][0]);
    		preSeries.add(1.0*i, pre[i][0]);
    	}
    	dataSet.addSeries(ySeries);
    	dataSet.addSeries(preSeries);
    	XYLineChartFrame chart=new XYLineChartFrame(applicationTitle, chartTitle, xLabel, yLabel, dataSet);
	    chart.pack( );          
	    RefineryUtilities.centerFrameOnScreen( chart );          
	    chart.setVisible( true ); 
    }
    
    
    public static void drawInterval(double[][] pre, double[][] y,double[][] up,double[][] down){
    	String applicationTitle="Figure";
    	String chartTitle="compared figure";
    	String xLabel="time";
    	String yLabel="value";
    	XYSeriesCollection dataSet =new XYSeriesCollection();
    	XYSeries ySeries=new XYSeries("y");
    	XYSeries preSeries=new XYSeries("pre");
    	XYSeries upSeries=new XYSeries("up");
    	XYSeries downSeries=new XYSeries("down");
    	for(int i=0;i<pre.length;i++){
    		ySeries.add(1.0*i, y[i][0]);
    		preSeries.add(1.0*i, pre[i][0]);
    		upSeries.add(1.0*i, up[i][0]);
    		downSeries.add(1.0*i, down[i][0]);
    	}
    	dataSet.addSeries(ySeries);
    	dataSet.addSeries(preSeries);
    	dataSet.addSeries(upSeries);
    	dataSet.addSeries(downSeries);
    	XYLineChartFrame chart=new XYLineChartFrame(applicationTitle, chartTitle, xLabel, yLabel, dataSet);
	    chart.pack( );          
	    RefineryUtilities.centerFrameOnScreen( chart );          
	    chart.setVisible( true ); 
	    XYLineAndShapeRenderer renderer=(XYLineAndShapeRenderer) chart.getXylineChart().getXYPlot().getRenderer();
	    renderer.setSeriesPaint(0, Color.RED);
	    renderer.setSeriesPaint(1, Color.green);
	    renderer.setSeriesPaint(2, Color.darkGray);
	    renderer.setSeriesPaint(3, Color.darkGray);
	    renderer.setBaseShapesVisible(false);

	    
	    
	    
	    
    }
    
    
    
}
