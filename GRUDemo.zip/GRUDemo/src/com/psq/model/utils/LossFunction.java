package com.psq.model.utils;



public class LossFunction {
	
	/**
	 * 批量获取损失函数�?
	 * @param pre
	 * @param label
	 * @param lossFunctionName
	 * @return
	 */
	public static double[] calLoss(Matrix pre, Matrix label, String ... lossFunctionName){
		if(lossFunctionName==null||lossFunctionName.length==0){
			lossFunctionName=new String[]{"MAE","MSE","RMSE","MAPE","R2"};
		}
		
		int len=lossFunctionName.length;
		
		double[] losses=new double[len];
		for(int i=0;i<len;i++){
			switch(lossFunctionName[i]){
			case "MAE": losses[i]=LossFunction.calMAE(pre, label);break;
			case "MSE": losses[i]=LossFunction.calMSE(pre, label);break;
			case "RMSE": losses[i]=LossFunction.calRMSE(pre, label);break;
			case "MAPE": losses[i]=LossFunction.calMAPE(pre, label);break;
			case "R2": losses[i]=LossFunction.calRsquare(pre, label);break;
			default: throw new IllegalArgumentException("loss function name is wrong!");
			}
		}
		
		return losses;
	}
	
	/**
	 * 批量获取损失函数�?
	 * @param pre
	 * @param label
	 * @param lossFunctionName
	 * @return
	 */
	public static double[] calLoss(Matrix pre, Matrix label, Matrix up, Matrix down, String ... lossFunctionName){
		if(lossFunctionName==null||lossFunctionName.length==0){
			lossFunctionName=new String[]{"MAE","MSE","RMSE","MAPE","R2","CP","MWP"};
		}
		
		int len=lossFunctionName.length;
		
		double[] losses=new double[len];
		for(int i=0;i<len;i++){
			switch(lossFunctionName[i]){
			case "MAE": losses[i]=LossFunction.calMAE(pre, label);break;
			case "MSE": losses[i]=LossFunction.calMSE(pre, label);break;
			case "RMSE": losses[i]=LossFunction.calRMSE(pre, label);break;
			case "MAPE": losses[i]=LossFunction.calMAPE(pre, label);break;
			case "R2": losses[i]=LossFunction.calRsquare(pre, label);break;
			case "CP": losses[i]=LossFunction.calCP(label, up, down);break;
			case "MWP": losses[i]=LossFunction.calMWP(label, up, down);break;			
			
			default: throw new IllegalArgumentException("loss function name is wrong!");
			}
		}
		
		return losses;
	}
	
	
	
	/**
	 * 计算均方根误�?
	 * @param pre
	 * @param label
	 * @return
	 */
	public static double calRMSE(Matrix pre, Matrix label){
		double loss=0.0;
		for(int i=0;i<pre.getRowDimension();i++){
			loss+=Math.pow(pre.get(i, 0)-label.get(i, 0), 2);
		}
		loss/=pre.getRowDimension();
		loss=Math.sqrt(loss);
		
		return loss;
	}
	/**
	 * 两�?�的均方误差，主要用于训练数据时采用
	 * @param pre
	 * @param label
	 * @return
	 */
	public static double calDoubleMSE(Matrix pre, Matrix label){
		double loss=0.0;
		for(int i=0;i<pre.getRowDimension();i++){
			loss+=0.5*Math.pow(pre.get(i, 0)-label.get(i, 0), 2);
		}
		
		loss/=pre.getRowDimension();
		return loss;
	}
	/**
	 * 计算平均绝对误差
	 * @param pre
	 * @param label
	 * @return
	 */
	public static double calMAE(Matrix pre, Matrix label){
		double loss=0.0;
		for(int i=0;i<pre.getRowDimension();i++){
			loss+=Math.abs(pre.get(i, 0)-label.get(i, 0));
		}
		
		loss/=pre.getRowDimension();
		return loss;		
	}
	/**
	 * 计算均方误差
	 * @param pre
	 * @param label
	 * @return
	 */
	public static double calMSE(Matrix pre, Matrix label){
		double loss=0.0;
		for(int i=0;i<pre.getRowDimension();i++){
			loss+=Math.pow(pre.get(i, 0)-label.get(i, 0), 2);
		}
		loss/=pre.getRowDimension();

		return loss;
	}
	/**
	 * 计算平均绝对百分比误�?
	 * @param pre
	 * @param label
	 * @return
	 */
	public static double calMAPE(Matrix pre, Matrix label){
		double loss=0.0;
		for(int i=0;i<pre.getRowDimension();i++){
			double num=(pre.get(i, 0)-label.get(i, 0))/label.get(i, 0);
			loss+=Math.abs(num);
		}
		
		loss/=pre.getRowDimension();
		return loss;
	}
	/**
	 * 计算R�?
	 * @param pre
	 * @param label
	 * @return
	 */
	public static double calRsquare(Matrix pre, Matrix label){
		double labelAvg=label.avg();
		double res=0.0;
		double rot=0.0;
		for(int i=0;i<pre.getRowDimension();i++){
			res+=Math.pow(pre.get(i, 0)-label.get(i, 0), 2);
			rot+=Math.pow(labelAvg-label.get(i, 0), 2);
		}
		double rSquare=1-res/rot;
		return rSquare;
	}
	/**
	 * 计算区间预测覆盖率CP指标
	 * @param label
	 * @param up
	 * @param down
	 * @return
	 */
	public static double calCP(Matrix label, Matrix up, Matrix down){
		int len=label.getRowDimension();
		int count=0;
		for(int i=0;i<len;i++){
			double labelDouble=label.get(i, 0);
			double upDouble=up.get(i, 0);
			double downDouble=down.get(i, 0);
			if(labelDouble>=downDouble && labelDouble<=upDouble){
				count++;
			}
		}		
		return 1.0*count/len;		
	}
	
	/**
	 * 计算区间预测MWP指标
	 * @param label
	 * @param up
	 * @param down
	 * @return
	 */
	public static double calMWP(Matrix label, Matrix up, Matrix down){
		int len=label.getRowDimension();
		double mwp=0.0;
		int count=0;
		for(int i=0;i<len;i++){
			double labelDouble=label.get(i, 0);
			double upDouble=up.get(i, 0);
			double downDouble=down.get(i, 0);
			if(labelDouble>0){
				mwp+=(upDouble-downDouble)/labelDouble;
			}else{
				count++;
			}
			
		}
		
		return mwp/(len-count);
	}
	
	
	
	
	
}
