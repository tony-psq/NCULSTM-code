package com.psq.model.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class FileOperatorUtil {


	
	
	/**
	 * 读取xls文件 通过对单元格遍历的形式来获取信息 精确判断单元格类型来取�??
	 * @param path 文件地址
	 * @param rowIndex 行id，可以是离散�?
	 * @param columnIndex 列id,可以是离散的
	 * @param sheetIndex 片id，从0�?始计�?
	 * @return
	 */
	public static Matrix readTableForXLS(String path, int[] rowIndex,
			int[] columnIndex,int sheetIndex) {
		Matrix result = new Matrix(rowIndex.length,columnIndex.length);
		try {
			InputStream ips = new FileInputStream(path);
			HSSFWorkbook wb = new HSSFWorkbook(ips);
			HSSFSheet sheet = wb.getSheetAt(sheetIndex);

			for (int i = 0; i < rowIndex.length; i++) {
				for (int j = 0; j < columnIndex.length; j++) {
					HSSFCell cell = sheet.getRow(rowIndex[i] - 1).getCell(columnIndex[j] - 1);

					int ind = j;
					switch (cell.getCellType()) {
					// 读取boolean类型
					case HSSFCell.CELL_TYPE_BOOLEAN:
						if(cell.getBooleanCellValue()){
							result.set(i, j,1.0 );
						}else{
							result.set(i, j,0.0 );
						}						
						break;
					case HSSFCell.CELL_TYPE_NUMERIC:
						if (HSSFDateUtil.isCellDateFormatted(cell)) {
							// 读取日期类型
							//cellMap.put(ind, cell.getDateCellValue());
						} else {
							// 读取数字类型
							result.set(i,j, cell.getNumericCellValue());
						}
						break;
					// 读取公式
					case HSSFCell.CELL_TYPE_FORMULA:
						//cellMap.put(ind, cell.getCellFormula());
						break;
					default:
						//cellMap.put(ind, cell.getStringCellValue());
						break;
					}
				}
			}
			ips.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	/**
	 * 读取xls文件 通过对单元格遍历的形式来获取信息 精确判断单元格类型来取�??
	 * @param path 文件地址
	 * @param rowIndex 行id,可以是离散的
	 * @param columnIndex 列id,可以是离散的
	 * @param sheetName 片名�?
	 * @return
	 */
	public static Matrix readTableForXLS(String path, int[] rowIndex,
			int[] columnIndex,String sheetName) {
		Matrix result = new Matrix(rowIndex.length,columnIndex.length);
		try {
			InputStream ips = new FileInputStream(path);
			HSSFWorkbook wb = new HSSFWorkbook(ips);
			HSSFSheet sheet = wb.getSheet(sheetName);

			for (int i = 0; i < rowIndex.length; i++) {
				for (int j = 0; j < columnIndex.length; j++) {
					HSSFCell cell = sheet.getRow(rowIndex[i] - 1).getCell(columnIndex[j] - 1);

					int ind = j;
					switch (cell.getCellType()) {
					// 读取boolean类型
					case HSSFCell.CELL_TYPE_BOOLEAN:
						if(cell.getBooleanCellValue()){
							result.set(i, j,1.0 );
						}else{
							result.set(i, j,0.0 );
						}						
						break;
					case HSSFCell.CELL_TYPE_NUMERIC:
						if (HSSFDateUtil.isCellDateFormatted(cell)) {
							// 读取日期类型
							//cellMap.put(ind, cell.getDateCellValue());
						} else {
							// 读取数字类型
							result.set(i,j, cell.getNumericCellValue());
						}
						break;
					// 读取公式
					case HSSFCell.CELL_TYPE_FORMULA:
						//cellMap.put(ind, cell.getCellFormula());
						break;
					default:
						//cellMap.put(ind, cell.getStringCellValue());
						break;
					}
				}
			}
			ips.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	/**
	 * 读取xlsx文件
	 * @param path
	 * @param rowIndex
	 * @param columnIndex
	 * @param sheetName
	 * @return
	 */
	public static Matrix readTableForXLSX(String path, int[] rowIndex,
			int[] columnIndex,String sheetName) {
		Matrix result = new Matrix(rowIndex.length,columnIndex.length);
		try {
			InputStream ips = new FileInputStream(path);
			XSSFWorkbook wb = new XSSFWorkbook(ips);
			XSSFSheet sheet = wb.getSheet(sheetName);
			
			for(int i=0;i<rowIndex.length;i++){
				for(int j=0;j<columnIndex.length;j++){
					XSSFCell cell=sheet.getRow(rowIndex[i] - 1).getCell(columnIndex[j] - 1);
					
					int ind=j;
					switch (cell.getCellType()) {
					// 读取boolean类型
					case XSSFCell.CELL_TYPE_BOOLEAN:
						//cellMap.put(ind, cell.getBooleanCellValue());
						break;
					case XSSFCell.CELL_TYPE_NUMERIC:
						if (HSSFDateUtil.isCellDateFormatted(cell)) {
							// 读取日期类型
							//cellMap.put(ind, cell.getDateCellValue());
						} else {
							// 读取数字类型
							result.set(i,j, cell.getNumericCellValue());
						}
						break;
					// 读取公式
					case XSSFCell.CELL_TYPE_FORMULA:
						//cellMap.put(ind, cell.getCellFormula());
						break;
					default:
						//cellMap.put(ind, cell.getStringCellValue());
						break;
					}					
				}
			}
			ips.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}
	
	/**
	 * 读取xlsx文件
	 * @param path
	 * @param rowIndex
	 * @param columnIndex
	 * @param sheetIndex
	 * @return
	 */
	public static Matrix readTableForXLSX(String path, int[] rowIndex,
			int[] columnIndex,int sheetIndex) {
		Matrix result = new Matrix(rowIndex.length,columnIndex.length);
		try {
			InputStream ips = new FileInputStream(path);
			XSSFWorkbook wb = new XSSFWorkbook(ips);
			XSSFSheet sheet = wb.getSheetAt(sheetIndex);
			
			for(int i=0;i<rowIndex.length;i++){
				for(int j=0;j<columnIndex.length;j++){
					XSSFCell cell=sheet.getRow(rowIndex[i] - 1).getCell(columnIndex[j] - 1);
					
					int ind=j;
					switch (cell.getCellType()) {
					// 读取boolean类型
					case XSSFCell.CELL_TYPE_BOOLEAN:
						//cellMap.put(ind, cell.getBooleanCellValue());
						break;
					case XSSFCell.CELL_TYPE_NUMERIC:
						if (HSSFDateUtil.isCellDateFormatted(cell)) {
							// 读取日期类型
							//cellMap.put(ind, cell.getDateCellValue());
						} else {
							// 读取数字类型
							result.set(i,j, cell.getNumericCellValue());
						}
						break;
					// 读取公式
					case XSSFCell.CELL_TYPE_FORMULA:
						//cellMap.put(ind, cell.getCellFormula());
						break;
					default:
						//cellMap.put(ind, cell.getStringCellValue());
						break;
					}					
				}
			}
			ips.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}
	
	/**
	 * 无差别读取excel文件
	 * @param path 地址
	 * @param rowIndex 行id，可以是离散的，计数起止与excel表格中一�?
	 * @param columnIndex 列id，可以是离散的，计数起止与excel表格中一�?
	 * @param sheetIndex 单元id,�?0�?�?
	 * @return
	 */
	public static Matrix readExcel(String path, int[] rowIndex,
			int[] columnIndex,int sheetIndex){
		if(path.endsWith(".xls")){
			return FileOperatorUtil.readTableForXLS(path, rowIndex, columnIndex, sheetIndex);
		}else if(path.endsWith(".xlsx")){
			return FileOperatorUtil.readTableForXLSX(path, rowIndex, columnIndex, sheetIndex);
		}else{
			System.out.println("文件类型有误�?");
		}
		return null;
	}
	/**
	 * 无差别读取excel文件
	 * @param path 地址
	 * @param rowIndex 行id，可以是离散的，计数起止与excel表格中一�?
	 * @param columnIndex 列id，可以是离散的，计数起止与excel表格中一�?
	 * @param sheetName 单元名称
	 * @return
	 */
	public static Matrix readExcel(String path, int[] rowIndex,
			int[] columnIndex,String sheetName){
		if(path.endsWith(".xls")){
			return FileOperatorUtil.readTableForXLS(path, rowIndex, columnIndex, sheetName);
		}else if(path.endsWith(".xlsx")){
			return FileOperatorUtil.readTableForXLSX(path, rowIndex, columnIndex, sheetName);
		}else{
			System.out.println("文件类型有误�?");
		}
		return null;
	}
	

	@SuppressWarnings("deprecation")
	public static boolean exportExcel(double[][][] losses, String excelPath) {

		File file = new File(excelPath);
		File parentFile = file.getParentFile();
		if (!parentFile.exists()) {
			parentFile.mkdirs();
		}

		try {
			file.createNewFile();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		boolean succ = true;
		// 声明�?个工作簿,默认保存为低版本�?
		HSSFWorkbook wb = new HSSFWorkbook();
		
		int caseNum=losses.length;

		String[] tableHead=new String[]{"MAE","MSE","RMSE","MAPE","R2"};
		
		for(int i=0;i<caseNum;i++){
			int time=losses[i].length;
			// 声明�?个sheet
			HSSFSheet sheet = wb.createSheet(i+"");
			// 设置sheet名称长度
			sheet.setDefaultColumnWidth((short) 15);
			// 生成�?个样�?
			HSSFCellStyle style = wb.createCellStyle();
			// 设置居中
			style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			// 创建表头
			HSSFRow row = sheet.createRow(0);// 表头名称
			
			for(int j=0;j<tableHead.length;j++){
				row.createCell(j).setCellValue(tableHead[j]);
				row.getCell(j).setCellStyle(style);
			}
			
			// 向表格里填充数据
			for (int k = 0; k < time; k++) {
				row = sheet.createRow(k + 1);
				for (int j = 0; j <tableHead.length; j++) {
					double value=losses[i][k][j];
					if(Double.isInfinite(value)||Double.isNaN(value)){
						losses[i][k][j]=99999;
					}
					// 写�??
					row.createCell(j).setCellValue(losses[i][k][j]);
					// 改样�?
					row.getCell(j).setCellStyle(style);
				}
			}
			
		}

		FileOutputStream out;
		try {
			out = new FileOutputStream(excelPath);
			wb.write(out);
			out.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			succ = false;
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			succ = false;
			e.printStackTrace();
		}

		return succ;
	}
	

	/**
	 * SWLSTM 预测结果导出
	 * @param content
	 * @param excelPath
	 * @param sheetIndex
	 * @return
	 */
	public static boolean exportExcel(double[][][] contents, String excelPath, String flag) {

		File file = new File(excelPath);
		File parentFile = file.getParentFile();
		if (!parentFile.exists()) {
			parentFile.mkdirs();
		}

		try {
			file.createNewFile();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		boolean succ = true;
		// 声明�?个工作簿,默认保存为低版本�?
		HSSFWorkbook wb = new HSSFWorkbook();
		
		for(int t=0;t<contents.length;t++){
			String[] tableHead=new String[]{"均�?�归�?","标签归一","均�?�还�?","标签还原","上限归一","上限还原","下限归一","下限还原","标准�?","其它信息"};
			
			double[][] content=contents[t];
			HSSFSheet sheet = wb.createSheet((t+1)+"");
			
			// 设置sheet名称长度
			sheet.setDefaultColumnWidth((short) 15);
			// 生成�?个样�?
			HSSFCellStyle style = wb.createCellStyle();
			// 设置居中
			style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			// 创建表头
			HSSFRow row = sheet.createRow(0);// 表头名称
			
			for(int j=0;j<content[0].length;j++){
				row.createCell(j).setCellValue(tableHead[j]);
				row.getCell(j).setCellStyle(style);
			}
			
			for(int i=0;i<content.length;i++){
				row = sheet.createRow(i + 1);
				for(int j=0;j<content[0].length;j++){
					if(!(i>=5&&j==9)){
						// 写�??
						row.createCell(j).setCellValue(content[i][j]);
						// 改样�?
						row.getCell(j).setCellStyle(style);
					}

				}
			}
		}
		

		
		FileOutputStream out;
		try {
			out = new FileOutputStream(excelPath);
			wb.write(out);
			out.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			succ = false;
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			succ = false;
			e.printStackTrace();
		}

		return succ;
	}

	
	public static boolean exportDataSet(double[][] train, double[][] validate, String excelPath){
		File file = new File(excelPath);
		File parentFile = file.getParentFile();
		if (!parentFile.exists()) {
			parentFile.mkdirs();
		}

		try {
			file.createNewFile();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		boolean succ = true;
		// 声明�?个工作簿,默认保存为低版本�?
		HSSFWorkbook wb = new HSSFWorkbook();
		String[] sheetName=new String[]{"train","validate"};
		double[][][] contents=new double[][][]{train,validate};
		for(int t=0;t<contents.length;t++){
			
			String[] tableHead=new String[train[0].length];
			for(int i=0;i<tableHead.length;i++){
				tableHead[i]="x"+(i+1);
				if(i==tableHead.length-1){
					tableHead[i]="Y";
				}
			}
			
			double[][] content=contents[t];
			HSSFSheet sheet = wb.createSheet(sheetName[t]);
			
			// 设置sheet名称长度
			sheet.setDefaultColumnWidth((short) 15);
			// 生成�?个样�?
			HSSFCellStyle style = wb.createCellStyle();
			// 设置居中
			style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			// 创建表头
			HSSFRow row = sheet.createRow(0);// 表头名称
			
			for(int j=0;j<tableHead.length;j++){
				row.createCell(j).setCellValue(tableHead[j]);
				row.getCell(j).setCellStyle(style);
			}
			
			for(int i=0;i<content.length;i++){
				row = sheet.createRow(i + 1);
				for(int j=0;j<content[0].length;j++){
						row.createCell(j).setCellValue(content[i][j]);
						// 改样�?
						row.getCell(j).setCellStyle(style);
				}
			}
		}
		

		
		FileOutputStream out;
		try {
			out = new FileOutputStream(excelPath);
			wb.write(out);
			out.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			succ = false;
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			succ = false;
			e.printStackTrace();
		}

		return succ;
	}

}
