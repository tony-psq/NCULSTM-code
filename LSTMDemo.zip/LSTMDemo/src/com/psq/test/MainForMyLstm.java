package com.psq.test;

import java.util.HashMap;

import com.psq.model.data.TimeSeriesData;
import com.psq.model.nLstmNetwork.LstmNetwork;
import com.psq.model.utils.FileOperatorUtil;
import com.psq.model.utils.Matrix;

public class MainForMyLstm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] columnIndex={1};//,2,3,4,5
		//String path="resources/data/windData/trainData.xlsx";
		//Matrix eData=FileOperatorUtil.readExcel(path, rowIndex, columnIndex,  0);
		
		int nodeFlag=columnIndex.length-1;
		
		double[][] data=new double[600][1];
		for(int i=0;i<data.length;i++){
			double num=-5*Math.PI+10.0*i/data.length*Math.PI;
			data[i][0]=Math.sin(num);//*num+Math.tan(num)*Math.cos(num);
		}
		
		int step=3;
		
		TimeSeriesData orgData=new TimeSeriesData(data,step,0.8, nodeFlag);
		Matrix trainX=orgData.getTrainX();
		Matrix trainY=orgData.getTrainY();
		Matrix validateX=orgData.getValidateX();
		Matrix validateY=orgData.getValidateY();
		
		int epochs=2000;
		double lr=0.2;
		LstmNetwork lstm=new LstmNetwork(step*columnIndex.length, step*columnIndex.length);
		lstm.train(trainX, trainY, 32, lr, epochs);
		lstm.validate(validateX, validateY);		

	}
	
	
	

	
}
