package com.psq.model.weight;



public class Weight {
	/**
	 * ������Ȩ��
	 */
	public WeightHX whxI;
	/**
	 * ������Ȩ��
	 */
	public WeightHX whxF;
	/**
	 * �����Ȩ��
	 */
	public WeightHX whxO;
	/**
	 * ״̬Ȩ��
	 */
	public WeightHX whxA;
	/**
	 * yȨ��
	 */
	public WeightY wY;
	
	/**
	 * ���캯����ʼ��
	 * @param xDim
	 * @param hiddenDim
	 */
	public Weight(int xDim, int hiddenDim){
		this.whxI=new WeightHX(xDim, hiddenDim);
		this.whxF=new WeightHX(xDim, hiddenDim);
		this.whxO=new WeightHX(xDim, hiddenDim);
		this.whxA=new WeightHX(xDim, hiddenDim);
		
		this.wY=new WeightY(1, hiddenDim);
	}
	
	public Weight(){
		
	}
	/**
	 * ����Ȩ�ظ���
	 * @param dWeight
	 * @param lr
	 */
	public void updateHX(DWeight dWeight, double lr){
		this.whxI.update(dWeight.dwhxI, lr);
		this.whxF.update(dWeight.dwhxF, lr);
		this.whxA.update(dWeight.dwhxA, lr);
		this.whxO.update(dWeight.dwhxO, lr);
		
	}
	
	public void updateY(DWeight dWeight, double lr){
		this.wY.update(dWeight.dwY, lr);
	}
	
	public Weight clone(){
		Weight newWeight=new Weight();
		newWeight.whxA=this.whxA.clone();
		newWeight.whxF=this.whxF.clone();
		newWeight.whxI=this.whxI.clone();
		newWeight.whxO=this.whxO.clone();
		newWeight.wY=this.wY.clone();
		
		return newWeight;
	}
	

}

