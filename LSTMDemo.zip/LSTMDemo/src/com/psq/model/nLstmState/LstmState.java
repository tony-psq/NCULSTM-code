package com.psq.model.nLstmState;

import com.psq.model.utils.Matrix;
import com.psq.model.weight.Weight;
import com.psq.model.weight.WeightHX;

public class LstmState {
	/**
	 * �?有时段输入门状�??
	 */
	public Matrix[] is;
	/**
	 * �?有时段遗忘门状�??
	 */
	public Matrix[] fs;
	/**
	 * �?有时段输出门状�??
	 */
	public Matrix[] os;
	/**
	 * �?有时段C波浪状�??
	 */
	public Matrix[] as;
	/**
	 * �?有时段输出状�?
	 */
	public Matrix[] hs;
	/**
	 * �?有时段cell状�??
	 */
	public Matrix[] cs;
	/**
	 * �?有时段预测�??
	 */
	public Matrix[] ys;
	/**
	 * 总时段长
	 */
	int step;
	/**
	 * 当前时段
	 */
	int currentStep;
	
	public LstmState(int step, int xDim, int hiddenDim){
		this.step=step+1;
		//当前时段�?1�?始计数，是因为给第一个时段预留一个全0的前�?时段
		this.currentStep=1;
		
		//输入�?
		this.is=new Matrix[step+1];
		for(int i=0;i<step+1;i++){
			is[i]=new Matrix(hiddenDim,1);
		}
		
		//遗忘�?
		this.fs=new Matrix[step+1];
		for(int i=0;i<step+1;i++){
			fs[i]=new Matrix(hiddenDim,1);
		}
		
		//输出�?
		this.os=new Matrix[step+1];
		for(int i=0;i<step+1;i++){
			os[i]=new Matrix(hiddenDim,1);
		}
		
		//当前输入的细胞状态，C波浪�?
		this.as=new Matrix[step+1];
		for(int i=0;i<step+1;i++){
			as[i]=new Matrix(hiddenDim,1);
		}
		
		//隐藏状�??
		this.hs=new Matrix[step+1];
		for(int i=0;i<step+1;i++){
			hs[i]=new Matrix(hiddenDim,1);
		}
		
		//cell状�??
		this.cs=new Matrix[step+1];
		for(int i=0;i<step+1;i++){
			cs[i]=new Matrix(hiddenDim,1);
		}
		
		//输出�?
		this.ys=new Matrix[step];
		int yDim=1;//这里应该是输出层的维�?
		for(int i=0;i<step;i++){
			ys[i]=new Matrix(yDim,1);
		}		
		
		
	}
	/**
	 * 前向传播
	 * @param weight
	 * @param x
	 */
	public void update(Weight weight, Matrix x){
		//前一时刻隐藏状�??
		Matrix preHt=this.hs[currentStep-1];
		//输入�?
		this.is[currentStep]=calGate(weight.whxI,preHt,x,"sigmoid");
		//遗忘�?
		this.fs[currentStep]=calGate(weight.whxF,preHt,x,"sigmoid");
		//输出�?
		this.os[currentStep]=calGate(weight.whxO,preHt,x,"sigmoid");
		//当前C波浪状�??
		this.as[currentStep]=calGate(weight.whxA,preHt,x,"tanh");
		
		//cell 状�??
		Matrix fc=fs[currentStep].arrayTimes(cs[currentStep-1]);
		Matrix ia=is[currentStep].arrayTimes(as[currentStep]);
		this.cs[currentStep]=fc.plus(ia);
		
		//隐藏状�??
		Matrix tc=Matrix.tanh(cs[currentStep]);
		this.hs[currentStep]=os[currentStep].arrayTimes(tc);
		
		Matrix yz=weight.wY.w.times(hs[currentStep]).plus(weight.wY.b);
		ys[currentStep-1]=Matrix.sigmoid(yz);
		currentStep++;
		
		
	}
	/**
	 * 计算门限结构
	 * @param whx
	 * @param preHt
	 * @param x
	 * @param activation
	 * @return
	 */
	private Matrix calGate(WeightHX whx, Matrix preHt, Matrix x, String activation){
		Matrix zh=whx.wh.times(preHt);
		Matrix zx=whx.wx.times(x.transpose());
		Matrix z=zh.plus(zx).plus(whx.b);
		Matrix a=z;
		if(activation.equals("sigmoid")){
			a=Matrix.sigmoid(z);
		}else if(activation.equals("tanh")){
			a=Matrix.tanh(z);
		}else{
			throw new IllegalArgumentException("activation function not implemented!");
		}
		
		return a;
	}
	

}
