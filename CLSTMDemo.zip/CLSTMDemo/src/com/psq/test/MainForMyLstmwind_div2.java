package com.psq.test;

import java.util.HashMap;

import com.psq.model.data.TimeSeriesData;
import com.psq.model.nLstmNetwork.LstmNetwork;
import com.psq.model.read.Read;
import com.psq.model.utils.FileOperatorUtil;
import com.psq.model.utils.Matrix;

public class MainForMyLstmwind_div2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] columnIndex={2};//,2,3,4,5
		Read read=new Read();
		
		//String path="C:\\Users\\tony\\eclipse-workspace\\CLSTMDemo";
		//Matrix eData=FileOperatorUtil.readExcel(path, rowIndex, columnIndex,  0);
		
		int nodeFlag=columnIndex.length-1;
		float[] data1=read.read("data.xls", 1,1,481,5);
		double[][] data=new double[481][1];
		for(int i=0;i<data.length;i++){
			data[i][0]=data1[i];//*num+Math.tan(num)*Math.cos(num);
		}
		 
		int step=2;	
         		TimeSeriesData orgData=new TimeSeriesData(data,step,0.8, nodeFlag);
		Matrix trainX=orgData.getTrainX();
		Matrix trainY=orgData.getTrainY();
		Matrix validateX=orgData.getValidateX();
		Matrix validateY=orgData.getValidateY();
		int epochs=2000;
		double lr=0.4;
		LstmNetwork lstm=new LstmNetwork(step*columnIndex.length,step*columnIndex.length);
		lstm.train(trainX, trainY, 32, lr, epochs);
		orgData.restore(lstm.validate(validateX, validateY));
 	}
	
	
	

	
}
