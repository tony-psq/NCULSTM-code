package com.psq.model.nLstmState;

import com.psq.model.utils.Matrix;
import com.psq.model.weight.Weight;
import com.psq.model.weight.WeightHX;

public class LstmState {
	/**
	 * 鎵�鏈夋椂娈佃緭鍏ラ棬鐘舵��?
	 */
	public Matrix[] us;
	/**
	 * 鎵�鏈夋椂娈甸仐蹇橀棬鐘舵��?
	 */
	public Matrix[] os;
	/** 
	 * 鎵�鏈夋椂娈礐娉㈡氮鐘舵��
	 */
	public Matrix[] as;
	/**
	 * 鎵�鏈夋椂娈佃緭鍑虹姸鎬�?
	 */
	public Matrix[] hs;
	/**
	 * 鎵�鏈夋椂娈礳ell鐘舵��
	 */
	public Matrix[] cs;
	/**
	 * 鎵�鏈夋椂娈甸娴嬪��
	 */
	public Matrix[] ys;
	/**
	 * 鎬绘椂娈甸暱
	 */
	int step;
	/**
	 * 褰撳墠鏃舵
	 */
	int currentStep;
	
	public LstmState(int step, int xDim, int hiddenDim){
		this.step=step+1;
		//褰撳墠鏃舵浠�1寮�濮嬭鏁帮紝鏄洜涓虹粰绗竴涓椂娈甸鐣欎竴涓�?0鐨勫墠涓�鏃舵
		this.currentStep=1;
		

		//閬楀繕闂�?
		this.us=new Matrix[step+1];
		for(int i=0;i<step+1;i++){
			us[i]=new Matrix(hiddenDim,1);
		}
		
		//杈撳嚭闂�?
		this.os=new Matrix[step+1];
		for(int i=0;i<step+1;i++){
			os[i]=new Matrix(hiddenDim,1);
		}
		
		//褰撳墠杈撳叆鐨勭粏鑳炵姸鎬侊紝C娉㈡氮绾�?
		this.as=new Matrix[step+1];
		for(int i=0;i<step+1;i++){
			as[i]=new Matrix(hiddenDim,1);
		}
		
		//闅愯棌鐘舵��?
		this.hs=new Matrix[step+1];
		for(int i=0;i<step+1;i++){
			hs[i]=new Matrix(hiddenDim,1);
		}
		
		//cell鐘舵��
		this.cs=new Matrix[step+1];
		for(int i=0;i<step+1;i++){
			cs[i]=new Matrix(hiddenDim,1);
		}
		
		//杈撳嚭鍊�?
		this.ys=new Matrix[step];
		int yDim=1;//杩欓噷搴旇鏄緭鍑哄眰鐨勭淮搴�?
		for(int i=0;i<step;i++){
			ys[i]=new Matrix(yDim,1);
		}		
		
		
	}
	/**
	 * 鍓嶅悜浼犳挱
	 * @param weight
	 * @param x
	 */
	public void update(Weight weight, Matrix x){
		//鍓嶄竴鏃跺埢闅愯棌鐘舵��?
		Matrix preHt=this.hs[currentStep-1];
		//杈撳叆闂�?
		this.us[currentStep]=calGate(weight.whxU,preHt,x,"sigmoid");
		//杈撳嚭闂�?
		this.os[currentStep]=calGate(weight.whxO,preHt,x,"sigmoid");
		//褰撳墠C娉㈡氮鐘舵��?
		this.as[currentStep]=calGate(weight.whxA,preHt,x,"tanh");
		
		//cell 鐘舵��
		Matrix fc=cs[currentStep-1].minus(us[currentStep].arrayTimes(cs[currentStep-1]));
				
		Matrix ia=us[currentStep].arrayTimes(as[currentStep]);
		this.cs[currentStep]=fc.plus(ia);
		
		//闅愯棌鐘舵��?
		Matrix tc=Matrix.tanh(cs[currentStep]);
		this.hs[currentStep]=os[currentStep].arrayTimes(tc);
		
		Matrix yz=weight.wY.w.times(hs[currentStep]).plus(weight.wY.b);
		ys[currentStep-1]=Matrix.sigmoid(yz);
		currentStep++;
		
		
	}
	/**
	 * 璁＄畻闂ㄩ檺缁撴�?
	 * @param whx
	 * @param preHt
	 * @param x
	 * @param activation
	 * @return
	 */
	private Matrix calGate(WeightHX whx, Matrix preHt, Matrix x, String activation){
		Matrix zh=whx.wh.times(preHt);
		Matrix zx=whx.wx.times(x.transpose());
		Matrix z=zh.plus(zx).plus(whx.b);
		Matrix a=z;
		if(activation.equals("sigmoid")){
			a=Matrix.sigmoid(z);
		}else if(activation.equals("tanh")){
			a=Matrix.tanh(z);
		}else{
			throw new IllegalArgumentException("activation function not implemented!");
		}
		
		return a;
	}
	
	

}
