package com.psq.model.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class FileOperatorUtil {


	
	
	/**
	 * 璇诲彇xls鏂囦�? 閫氳繃�?�瑰崟鍏冩牸閬嶅巻鐨勫舰寮忔潵鑾峰彇淇℃�? 绮剧‘鍒ゆ柇鍗曞厓鏍肩被鍨嬫潵鍙栧��?
	 * @param path 鏂囦欢鍦板潃
	 * @param rowIndex 琛宨d锛屽彲浠ユ槸绂绘暎鐨�?
	 * @param columnIndex 鍒梚d,鍙互鏄鏁ｇ�?
	 * @param sheetIndex 鐗噄d锛屼�?0寮�濮嬭鏁�?
	 * @return
	 */
	public static Matrix readTableForXLS(String path, int[] rowIndex,
			int[] columnIndex,int sheetIndex) {
		Matrix result = new Matrix(rowIndex.length,columnIndex.length);
		try {
			InputStream ips = new FileInputStream(path);
			HSSFWorkbook wb = new HSSFWorkbook(ips);
			HSSFSheet sheet = wb.getSheetAt(sheetIndex);

			for (int i = 0; i < rowIndex.length; i++) {
				for (int j = 0; j < columnIndex.length; j++) {
					HSSFCell cell = sheet.getRow(rowIndex[i] - 1).getCell(columnIndex[j] - 1);

					int ind = j;
					switch (cell.getCellType()) {
					// 璇诲彇boolean绫诲�?
					case HSSFCell.CELL_TYPE_BOOLEAN:
						if(cell.getBooleanCellValue()){
							result.set(i, j,1.0 );
						}else{
							result.set(i, j,0.0 );
						}						
						break;
					case HSSFCell.CELL_TYPE_NUMERIC:
						if (HSSFDateUtil.isCellDateFormatted(cell)) {
							// 璇诲彇鏃ユ湡绫诲�?
							//cellMap.put(ind, cell.getDateCellValue());
						} else {
							// 璇诲彇鏁板瓧绫诲�?
							result.set(i,j, cell.getNumericCellValue());
						}
						break;
					// 璇诲彇鍏�?�?
					case HSSFCell.CELL_TYPE_FORMULA:
						//cellMap.put(ind, cell.getCellFormula());
						break;
					default:
						//cellMap.put(ind, cell.getStringCellValue());
						break;
					}
				}
			}
			ips.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	/**
	 * 璇诲彇xls鏂囦�? 閫氳繃�?�瑰崟鍏冩牸閬嶅巻鐨勫舰寮忔潵鑾峰彇淇℃�? 绮剧‘鍒ゆ柇鍗曞厓鏍肩被鍨嬫潵鍙栧��?
	 * @param path 鏂囦欢鍦板潃
	 * @param rowIndex 琛宨d,鍙互鏄鏁ｇ�?
	 * @param columnIndex 鍒梚d,鍙互鏄鏁ｇ�?
	 * @param sheetName 鐗囧悕绉�?
	 * @return
	 */
	public static Matrix readTableForXLS(String path, int[] rowIndex,
			int[] columnIndex,String sheetName) {
		Matrix result = new Matrix(rowIndex.length,columnIndex.length);
		try {
			InputStream ips = new FileInputStream(path);
			HSSFWorkbook wb = new HSSFWorkbook(ips);
			HSSFSheet sheet = wb.getSheet(sheetName);

			for (int i = 0; i < rowIndex.length; i++) {
				for (int j = 0; j < columnIndex.length; j++) {
					HSSFCell cell = sheet.getRow(rowIndex[i] - 1).getCell(columnIndex[j] - 1);

					int ind = j;
					switch (cell.getCellType()) {
					// 璇诲彇boolean绫诲�?
					case HSSFCell.CELL_TYPE_BOOLEAN:
						if(cell.getBooleanCellValue()){
							result.set(i, j,1.0 );
						}else{
							result.set(i, j,0.0 );
						}						
						break;
					case HSSFCell.CELL_TYPE_NUMERIC:
						if (HSSFDateUtil.isCellDateFormatted(cell)) {
							// 璇诲彇鏃ユ湡绫诲�?
							//cellMap.put(ind, cell.getDateCellValue());
						} else {
							// 璇诲彇鏁板瓧绫诲�?
							result.set(i,j, cell.getNumericCellValue());
						}
						break;
					// 璇诲彇鍏�?�?
					case HSSFCell.CELL_TYPE_FORMULA:
						//cellMap.put(ind, cell.getCellFormula());
						break;
					default:
						//cellMap.put(ind, cell.getStringCellValue());
						break;
					}
				}
			}
			ips.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	/**
	 * 璇诲彇xlsx鏂囦�?
	 * @param path
	 * @param rowIndex
	 * @param columnIndex
	 * @param sheetName
	 * @return
	 */
	public static Matrix readTableForXLSX(String path, int[] rowIndex,
			int[] columnIndex,String sheetName) {
		Matrix result = new Matrix(rowIndex.length,columnIndex.length);
		try {
			InputStream ips = new FileInputStream(path);
			XSSFWorkbook wb = new XSSFWorkbook(ips);
			XSSFSheet sheet = wb.getSheet(sheetName);
			
			for(int i=0;i<rowIndex.length;i++){
				for(int j=0;j<columnIndex.length;j++){
					XSSFCell cell=sheet.getRow(rowIndex[i] - 1).getCell(columnIndex[j] - 1);
					
					int ind=j;
					switch (cell.getCellType()) {
					// 璇诲彇boolean绫诲�?
					case XSSFCell.CELL_TYPE_BOOLEAN:
						//cellMap.put(ind, cell.getBooleanCellValue());
						break;
					case XSSFCell.CELL_TYPE_NUMERIC:
						if (HSSFDateUtil.isCellDateFormatted(cell)) {
							// 璇诲彇鏃ユ湡绫诲�?
							//cellMap.put(ind, cell.getDateCellValue());
						} else {
							// 璇诲彇鏁板瓧绫诲�?
							result.set(i,j, cell.getNumericCellValue());
						}
						break;
					// 璇诲彇鍏�?�?
					case XSSFCell.CELL_TYPE_FORMULA:
						//cellMap.put(ind, cell.getCellFormula());
						break;
					default:
						//cellMap.put(ind, cell.getStringCellValue());
						break;
					}					
				}
			}
			ips.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}
	
	/**
	 * 璇诲彇xlsx鏂囦�?
	 * @param path
	 * @param rowIndex
	 * @param columnIndex
	 * @param sheetIndex
	 * @return
	 */
	public static Matrix readTableForXLSX(String path, int[] rowIndex,
			int[] columnIndex,int sheetIndex) {
		Matrix result = new Matrix(rowIndex.length,columnIndex.length);
		try {
			InputStream ips = new FileInputStream(path);
			XSSFWorkbook wb = new XSSFWorkbook(ips);
			XSSFSheet sheet = wb.getSheetAt(sheetIndex);
			
			for(int i=0;i<rowIndex.length;i++){
				for(int j=0;j<columnIndex.length;j++){
					XSSFCell cell=sheet.getRow(rowIndex[i] - 1).getCell(columnIndex[j] - 1);
					
					int ind=j;
					switch (cell.getCellType()) {
					// 璇诲彇boolean绫诲�?
					case XSSFCell.CELL_TYPE_BOOLEAN:
						//cellMap.put(ind, cell.getBooleanCellValue());
						break;
					case XSSFCell.CELL_TYPE_NUMERIC:
						if (HSSFDateUtil.isCellDateFormatted(cell)) {
							// 璇诲彇鏃ユ湡绫诲�?
							//cellMap.put(ind, cell.getDateCellValue());
						} else {
							// 璇诲彇鏁板瓧绫诲�?
							result.set(i,j, cell.getNumericCellValue());
						}
						break;
					// 璇诲彇鍏�?�?
					case XSSFCell.CELL_TYPE_FORMULA:
						//cellMap.put(ind, cell.getCellFormula());
						break;
					default:
						//cellMap.put(ind, cell.getStringCellValue());
						break;
					}					
				}
			}
			ips.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}
	
	/**
	 * 鏃犲樊鍒鍙杄xcel鏂囦�?
	 * @param path 鍦板�?
	 * @param rowIndex 琛宨d锛屽彲浠ユ槸绂绘暎鐨勶紝璁℃暟璧锋涓巈xcel琛ㄦ牸涓竴鑷�
	 * @param columnIndex 鍒梚d锛屽彲浠ユ槸绂绘暎鐨勶紝璁℃暟璧锋涓巈xcel琛ㄦ牸涓竴鑷�
	 * @param sheetIndex 鍗曞厓id,浠�0寮�濮�
	 * @return
	 */
	public static Matrix readExcel(String path, int[] rowIndex,
			int[] columnIndex,int sheetIndex){
		if(path.endsWith(".xls")){
			return FileOperatorUtil.readTableForXLS(path, rowIndex, columnIndex, sheetIndex);
		}else if(path.endsWith(".xlsx")){
			return FileOperatorUtil.readTableForXLSX(path, rowIndex, columnIndex, sheetIndex);
		}else{
			System.out.println("鏂囦欢绫诲�?�鏈夎锛�");
		}
		return null;
	}
	/**
	 * 鏃犲樊鍒鍙杄xcel鏂囦�?
	 * @param path 鍦板�?
	 * @param rowIndex 琛宨d锛屽彲浠ユ槸绂绘暎鐨勶紝璁℃暟璧锋涓巈xcel琛ㄦ牸涓竴鑷�
	 * @param columnIndex 鍒梚d锛屽彲浠ユ槸绂绘暎鐨勶紝璁℃暟璧锋涓巈xcel琛ㄦ牸涓竴鑷�
	 * @param sheetName 鍗曞厓鍚嶇�?
	 * @return
	 */
	public static Matrix readExcel(String path, int[] rowIndex,
			int[] columnIndex,String sheetName){
		if(path.endsWith(".xls")){
			return FileOperatorUtil.readTableForXLS(path, rowIndex, columnIndex, sheetName);
		}else if(path.endsWith(".xlsx")){
			return FileOperatorUtil.readTableForXLSX(path, rowIndex, columnIndex, sheetName);
		}else{
			System.out.println("鏂囦欢绫诲�?�鏈夎锛�");
		}
		return null;
	}
	

	@SuppressWarnings("deprecation")
	public static boolean exportExcel(double[][][] losses, String excelPath) {

		File file = new File(excelPath);
		File parentFile = file.getParentFile();
		if (!parentFile.exists()) {
			parentFile.mkdirs();
		}

		try {
			file.createNewFile();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		boolean succ = true;
		// 澹版槑涓�涓伐浣滅�?,榛樿淇濆瓨涓轰綆鐗堟湰鐨�
		HSSFWorkbook wb = new HSSFWorkbook();
		
		int caseNum=losses.length;

		String[] tableHead=new String[]{"MAE","MSE","RMSE","MAPE","R2"};
		
		for(int i=0;i<caseNum;i++){
			int time=losses[i].length;
			// 澹版槑涓�涓猻heet
			HSSFSheet sheet = wb.createSheet(i+"");
			// 璁剧疆sheet鍚嶇О�?垮害
			sheet.setDefaultColumnWidth((short) 15);
			// 鐢熸垚涓�涓牱寮�
			HSSFCellStyle style = wb.createCellStyle();
			// 璁剧疆灞呬腑
			style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			// 鍒涘缓琛ㄥご
			HSSFRow row = sheet.createRow(0);// 琛ㄥご鍚嶇�?
			
			for(int j=0;j<tableHead.length;j++){
				row.createCell(j).setCellValue(tableHead[j]);
				row.getCell(j).setCellStyle(style);
			}
			
			// 鍚戣〃鏍奸噷濉厖鏁版嵁
			for (int k = 0; k < time; k++) {
				row = sheet.createRow(k + 1);
				for (int j = 0; j <tableHead.length; j++) {
					double value=losses[i][k][j];
					if(Double.isInfinite(value)||Double.isNaN(value)){
						losses[i][k][j]=99999;
					}
					// 鍐欏��
					row.createCell(j).setCellValue(losses[i][k][j]);
					// �?规牱寮�
					row.getCell(j).setCellStyle(style);
				}
			}
			
		}

		FileOutputStream out;
		try {
			out = new FileOutputStream(excelPath);
			wb.write(out);
			out.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			succ = false;
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			succ = false;
			e.printStackTrace();
		}

		return succ;
	}
	

	/**
	 * SWLSTM 棰勬祴缁撴灉瀵煎�?
	 * @param content
	 * @param excelPath
	 * @param sheetIndex
	 * @return
	 */
	public static boolean exportExcel(double[][][] contents, String excelPath, String flag) {

		File file = new File(excelPath);
		File parentFile = file.getParentFile();
		if (!parentFile.exists()) {
			parentFile.mkdirs();
		}

		try {
			file.createNewFile();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		boolean succ = true;
		// 澹版槑涓�涓伐浣滅�?,榛樿淇濆瓨涓轰綆鐗堟湰鐨�
		HSSFWorkbook wb = new HSSFWorkbook();
		
		for(int t=0;t<contents.length;t++){
			String[] tableHead=new String[]{"鍧囧�煎綊涓�?","鏍囩褰掍竴","鍧囧�艰繕鍘�?","鏍囩杩樺師","涓婇檺褰掍竴","涓婇檺杩樺師","涓嬮檺褰掍竴","涓嬮檺杩樺師","鏍囧噯宸�?","鍏跺畠淇℃伅"};
			
			double[][] content=contents[t];
			HSSFSheet sheet = wb.createSheet((t+1)+"");
			
			// 璁剧疆sheet鍚嶇О�?垮害
			sheet.setDefaultColumnWidth((short) 15);
			// 鐢熸垚涓�涓牱寮�
			HSSFCellStyle style = wb.createCellStyle();
			// 璁剧疆灞呬腑
			style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			// 鍒涘缓琛ㄥご
			HSSFRow row = sheet.createRow(0);// 琛ㄥご鍚嶇�?
			
			for(int j=0;j<content[0].length;j++){
				row.createCell(j).setCellValue(tableHead[j]);
				row.getCell(j).setCellStyle(style);
			}
			
			for(int i=0;i<content.length;i++){
				row = sheet.createRow(i + 1);
				for(int j=0;j<content[0].length;j++){
					if(!(i>=5&&j==9)){
						// 鍐欏��
						row.createCell(j).setCellValue(content[i][j]);
						// �?规牱寮�
						row.getCell(j).setCellStyle(style);
					}

				}
			}
		}
		

		
		FileOutputStream out;
		try {
			out = new FileOutputStream(excelPath);
			wb.write(out);
			out.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			succ = false;
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			succ = false;
			e.printStackTrace();
		}

		return succ;
	}

	
	public static boolean exportDataSet(double[][] train, double[][] validate, String excelPath){
		File file = new File(excelPath);
		File parentFile = file.getParentFile();
		if (!parentFile.exists()) {
			parentFile.mkdirs();
		}

		try {
			file.createNewFile();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		boolean succ = true;
		// 澹版槑涓�涓伐浣滅�?,榛樿淇濆瓨涓轰綆鐗堟湰鐨�
		HSSFWorkbook wb = new HSSFWorkbook();
		String[] sheetName=new String[]{"train","validate"};
		double[][][] contents=new double[][][]{train,validate};
		for(int t=0;t<contents.length;t++){
			
			String[] tableHead=new String[train[0].length];
			for(int i=0;i<tableHead.length;i++){
				tableHead[i]="x"+(i+1);
				if(i==tableHead.length-1){
					tableHead[i]="Y";
				}
			}
			
			double[][] content=contents[t];
			HSSFSheet sheet = wb.createSheet(sheetName[t]);
			
			// 璁剧疆sheet鍚嶇О�?垮害
			sheet.setDefaultColumnWidth((short) 15);
			// 鐢熸垚涓�涓牱寮�
			HSSFCellStyle style = wb.createCellStyle();
			// 璁剧疆灞呬腑
			style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			// 鍒涘缓琛ㄥご
			HSSFRow row = sheet.createRow(0);// 琛ㄥご鍚嶇�?
			
			for(int j=0;j<tableHead.length;j++){
				row.createCell(j).setCellValue(tableHead[j]);
				row.getCell(j).setCellStyle(style);
			}
			
			for(int i=0;i<content.length;i++){
				row = sheet.createRow(i + 1);
				for(int j=0;j<content[0].length;j++){
						row.createCell(j).setCellValue(content[i][j]);
						// �?规牱寮�
						row.getCell(j).setCellStyle(style);
				}
			}
		}
		

		
		FileOutputStream out;
		try {
			out = new FileOutputStream(excelPath);
			wb.write(out);
			out.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			succ = false;
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			succ = false;
			e.printStackTrace();
		}

		return succ;
	}

}
