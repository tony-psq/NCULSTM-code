package com.psq.model.utils;



public class LossFunction {
	
	/**
	 * 鎵归噺鑾峰彇鎹熷け鍑芥暟鍊�
	 * @param pre
	 * @param label
	 * @param lossFunctionName
	 * @return
	 */
	public static double[] calLoss(Matrix pre, Matrix label, String ... lossFunctionName){
		if(lossFunctionName==null||lossFunctionName.length==0){
			lossFunctionName=new String[]{"MAE","MSE","RMSE","MAPE","R2"};
		}
		
		int len=lossFunctionName.length;
		
		double[] losses=new double[len];
		for(int i=0;i<len;i++){
			switch(lossFunctionName[i]){
			case "MAE": losses[i]=LossFunction.calMAE(pre, label);break;
			case "MSE": losses[i]=LossFunction.calMSE(pre, label);break;
			case "RMSE": losses[i]=LossFunction.calRMSE(pre, label);break;
			case "MAPE": losses[i]=LossFunction.calMAPE(pre, label);break;
			case "R2": losses[i]=LossFunction.calRsquare(pre, label);break;
			default: throw new IllegalArgumentException("loss function name is wrong!");
			}
		}
		
		return losses;
	}
	
	/**
	 * 鎵归噺鑾峰彇鎹熷け鍑芥暟鍊�
	 * @param pre
	 * @param label
	 * @param lossFunctionName
	 * @return
	 */
	public static double[] calLoss(Matrix pre, Matrix label, Matrix up, Matrix down, String ... lossFunctionName){
		if(lossFunctionName==null||lossFunctionName.length==0){
			lossFunctionName=new String[]{"MAE","MSE","RMSE","MAPE","R2","CP","MWP"};
		}
		
		int len=lossFunctionName.length;
		
		double[] losses=new double[len];
		for(int i=0;i<len;i++){
			switch(lossFunctionName[i]){
			case "MAE": losses[i]=LossFunction.calMAE(pre, label);break;
			case "MSE": losses[i]=LossFunction.calMSE(pre, label);break;
			case "RMSE": losses[i]=LossFunction.calRMSE(pre, label);break;
			case "MAPE": losses[i]=LossFunction.calMAPE(pre, label);break;
			case "R2": losses[i]=LossFunction.calRsquare(pre, label);break;
			case "CP": losses[i]=LossFunction.calCP(label, up, down);break;
			case "MWP": losses[i]=LossFunction.calMWP(label, up, down);break;			
			
			default: throw new IllegalArgumentException("loss function name is wrong!");
			}
		}
		
		return losses;
	}
	
	
	
	/**
	 * 璁＄畻鍧囨柟鏍硅宸�?
	 * @param pre
	 * @param label
	 * @return
	 */
	public static double calRMSE(Matrix pre, Matrix label){
		double loss=0.0;
		for(int i=0;i<pre.getRowDimension();i++){
			loss+=Math.pow(pre.get(i, 0)-label.get(i, 0), 2);
		}
		loss/=pre.getRowDimension();
		loss=Math.sqrt(loss);
		
		return loss;
	}
	/**
	 * 涓ゅ�嶇殑鍧囨柟璇樊锛屼富瑕佺敤浜庤缁冩暟鎹椂閲囩�?
	 * @param pre
	 * @param label
	 * @return
	 */
	public static double calDoubleMSE(Matrix pre, Matrix label){
		double loss=0.0;
		for(int i=0;i<pre.getRowDimension();i++){
			loss+=0.5*Math.pow(pre.get(i, 0)-label.get(i, 0), 2);
		}
		
		loss/=pre.getRowDimension();
		return loss;
	}
	/**
	 * 璁＄畻骞冲潎缁濆璇樊
	 * @param pre
	 * @param label
	 * @return
	 */
	public static double calMAE(Matrix pre, Matrix label){
		double loss=0.0;
		for(int i=0;i<pre.getRowDimension();i++){
			loss+=Math.abs(pre.get(i, 0)-label.get(i, 0));
		}
		
		loss/=pre.getRowDimension();
		return loss;		
	}
	/**
	 * 璁＄畻鍧囨柟璇�?
	 * @param pre
	 * @param label
	 * @return
	 */
	public static double calMSE(Matrix pre, Matrix label){
		double loss=0.0;
		for(int i=0;i<pre.getRowDimension();i++){
			loss+=Math.pow(pre.get(i, 0)-label.get(i, 0), 2);
		}
		loss/=pre.getRowDimension();

		return loss;
	}
	/**
	 * 璁＄畻骞冲潎缁濆鐧惧垎姣旇宸�?
	 * @param pre
	 * @param label
	 * @return
	 */
	public static double calMAPE(Matrix pre, Matrix label){
		double loss=0.0;
		for(int i=0;i<pre.getRowDimension();i++){
			double num=(pre.get(i, 0)-label.get(i, 0))/label.get(i, 0);
			loss+=Math.abs(num);
		}
		
		loss/=pre.getRowDimension();
		return loss;
	}
	/**
	 * 璁＄畻R鏂�
	 * @param pre
	 * @param label
	 * @return
	 */
	public static double calRsquare(Matrix pre, Matrix label){
		double labelAvg=label.avg();
		double res=0.0;
		double rot=0.0;
		for(int i=0;i<pre.getRowDimension();i++){
			res+=Math.pow(pre.get(i, 0)-label.get(i, 0), 2);
			rot+=Math.pow(labelAvg-label.get(i, 0), 2);
		}
		double rSquare=1-res/rot;
		return rSquare;
	}
	/**
	 * 璁＄畻鍖洪棿棰勬祴瑕嗙洊鐜嘋P鎸囨�?
	 * @param label
	 * @param up
	 * @param down
	 * @return
	 */
	public static double calCP(Matrix label, Matrix up, Matrix down){
		int len=label.getRowDimension();
		int count=0;
		for(int i=0;i<len;i++){
			double labelDouble=label.get(i, 0);
			double upDouble=up.get(i, 0);
			double downDouble=down.get(i, 0);
			if(labelDouble>=downDouble && labelDouble<=upDouble){
				count++;
			}
		}		
		return 1.0*count/len;		
	}
	
	/**
	 * 璁＄畻鍖洪棿棰勬祴MWP鎸囨�?
	 * @param label
	 * @param up
	 * @param down
	 * @return
	 */
	public static double calMWP(Matrix label, Matrix up, Matrix down){
		int len=label.getRowDimension();
		double mwp=0.0;
		int count=0;
		for(int i=0;i<len;i++){
			double labelDouble=label.get(i, 0);
			double upDouble=up.get(i, 0);
			double downDouble=down.get(i, 0);
			if(labelDouble>0){
				mwp+=(upDouble-downDouble)/labelDouble;
			}else{
				count++;
			}
			
		}
		
		return mwp/(len-count);
	}
	
	
	
	
	
}
