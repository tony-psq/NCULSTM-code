package com.psq.model.data;

import com.psq.model.utils.Matrix;

public class Data {
	/**
	 * 璁粌闆嗙壒寰�
	 */
	protected Matrix trainX;
	/**
	 * 璁粌闆嗘爣绛�
	 */
	protected Matrix trainY;
	
	protected Matrix validateX;
	
	protected Matrix validateY;

	public Matrix getTrainX() {
		return trainX; 
	}

	public void setTrainX(Matrix trainX) {
		this.trainX = trainX;
	}

	public Matrix getTrainY() {
		return trainY;
	}

	public void setTrainY(Matrix trainY) {
		this.trainY = trainY;
	}

	public Matrix getValidateX() {
		return validateX;
	}

	public void setValidateX(Matrix validateX) {
		this.validateX = validateX;
	}

	public Matrix getValidateY() {
		return validateY;
	}

	public void setValidateY(Matrix validateY) {
		this.validateY = validateY;
	}
	
	
}
