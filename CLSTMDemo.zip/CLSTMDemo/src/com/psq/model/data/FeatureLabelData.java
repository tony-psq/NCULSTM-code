package com.psq.model.data;

import com.psq.model.utils.Matrix;

public class FeatureLabelData{
	
	Matrix[] trainXs;
	
	Matrix[] trainYs; 
	
	Matrix[] validateXs;
	
	Matrix[] validateYs;
	
	double[] mins;
	
	double[] maxs;
	
	
	Matrix normData;
	//产生训练集和验证�? sep为训练集的百分比，xdims为维度，case为数据长�?
	public FeatureLabelData(Matrix matrix, int[] xDims,int caseNum , double sep){
		int row=matrix.getRowDimension();
		int col=matrix.getColumnDimension();
		mins=new double[col];
		maxs=new double[col];
		this.normalize(matrix,true);
		trainXs=new Matrix[caseNum];
		trainYs=new Matrix[caseNum];
		validateXs=new Matrix[caseNum];
		validateYs=new Matrix[caseNum];
		
		int sepIndex=(int)(row*sep);
		int start=0;
		for(int i=0;i<caseNum;i++){
			trainXs[i]=this.normData.getMatrix(0, sepIndex, start, start+xDims[i]-1);
			trainYs[i]=this.normData.getMatrix(0, sepIndex, start+xDims[i], start+xDims[i]);
			validateXs[i]=this.normData.getMatrix(sepIndex+1, row-1, start, start+xDims[i]-1);
			validateYs[i]=this.normData.getMatrix(sepIndex+1, row-1, start+xDims[i], start+xDims[i]);
			start=+xDims[i]+1;
		}
	}
	
	/**
	 * 鏄惁褰掍竴鍖�
	 * @param matrix
	 * @param xDims
	 * @param caseNum
	 * @param sep
	 * @param isNorm
	 */
	public FeatureLabelData(Matrix matrix, int[] xDims,int caseNum , double sep, boolean isNorm){
		int row=matrix.getRowDimension();
		int col=matrix.getColumnDimension();
		mins=new double[col];
		maxs=new double[col];
		this.normalize(matrix,isNorm);
		trainXs=new Matrix[caseNum];
		trainYs=new Matrix[caseNum];
		validateXs=new Matrix[caseNum];
		validateYs=new Matrix[caseNum];
		
		int sepIndex=(int)Math.floor(row*sep)-1;
		int start=0;
		for(int i=0;i<caseNum;i++){
			
			//前dim列预测第dim+1�?
			trainXs[i]=this.normData.getMatrix(0, sepIndex, start, start+xDims[i]-1);
			trainYs[i]=this.normData.getMatrix(0, sepIndex, start+xDims[i], start+xDims[i]);
			validateXs[i]=this.normData.getMatrix(sepIndex+1, row-1, start, start+xDims[i]-1);
			validateYs[i]=this.normData.getMatrix(sepIndex+1, row-1, start+xDims[i], start+xDims[i]);
			start=start+xDims[i]+1; 
		}
	}
	
	/**
	 * 褰掍竴鍖栨瘡涓�鍒�
	 * @param matrix
	 */
	//归一�?
	private void normalize(Matrix matrix, boolean isNorm){
		if(isNorm){
			int col=matrix.getColumnDimension();
			int row=matrix.getRowDimension();
			normData=new Matrix(row, col);
			for(int i=0;i<col;i++){
				Matrix m=matrix.getMatrix(0, row-1, i, i);
				double min=m.min();
				double max=m.max();
				mins[i]=min;
				maxs[i]=max;
				
				m=m.minus(min).times(1.0/(max-min));
				normData.setMatrix(0, row-1, i, i, m.copy());
			}
		}else{
			int col=matrix.getColumnDimension();
			int row=matrix.getRowDimension();
			normData=new Matrix(row, col);
			for(int i=0;i<col;i++){
				Matrix m=matrix.getMatrix(0, row-1, i, i);
				normData.setMatrix(0, row-1, i, i, m.copy());
			}
		}

	}

	public Matrix[] getTrainXs() {
		return trainXs;
	}

	public void setTrainXs(Matrix[] trainXs) {
		this.trainXs = trainXs;
	}

	public Matrix[] getTrainYs() {
		return trainYs;
	}

	public void setTrainYs(Matrix[] trainYs) {
		this.trainYs = trainYs;
	}

	public Matrix[] getValidateXs() {
		return validateXs;
	}

	public void setValidateXs(Matrix[] validateXs) {
		this.validateXs = validateXs;
	}

	public Matrix[] getValidateYs() {
		return validateYs;
	}

	public void setValidateYs(Matrix[] validateYs) {
		this.validateYs = validateYs;
	}
	
	
	
	
}
