package com.psq.model.weight;

import com.psq.model.utils.Matrix;

public class DWeight {
	/**
	 * 涓�涓牱鏈殑鐗瑰�?
	 */
	int xDim;
	/**
	 * 闅愯棌灞傝妭鐐规�?
	 */
	int hiddenDim;
	/** 
	 * dwh,dwx,db
	 */
	public DWeightHX dwhxU,dwhxO,dwhxA;
	public DWeightY dwY;
	
	public DWeight(int xDim,int hiddenDim){
		this.xDim=xDim;
		this.hiddenDim=hiddenDim;
		
		this.dwhxU=new DWeightHX(xDim, hiddenDim);
		this.dwhxO=new DWeightHX(xDim, hiddenDim);
		this.dwhxA=new DWeightHX(xDim, hiddenDim);
		
		this.dwY=new DWeightY(1,hiddenDim);
		
	}
	/**
	 * 璁＄畻鍚勪釜鏉冮噸鐭╅樀鐨勫亸�?�兼�?
	 * @param di
	 * @param df
	 * @param da
	 * @param doo
	 * @param hss
	 * @param x
	 */
	public void update(Matrix du, Matrix da, Matrix doo, Matrix hss, Matrix x){
		this.dwhxU.calGrad(du, hss, x);
		this.dwhxA.calGrad(da, hss, x);
		this.dwhxO.calGrad(doo, hss, x);
	}
	/**
	 * 鏉冮噸鍚戦噺鍙犲�?
	 * @param dWeight
	 * @return
	 */
	public DWeight add(DWeight dWeight){
		DWeight result=new DWeight(this.xDim,this.hiddenDim);
		result.dwhxU=this.dwhxU.add(dWeight.dwhxU);
		result.dwhxA=this.dwhxA.add(dWeight.dwhxA);
		result.dwhxO=this.dwhxO.add(dWeight.dwhxO);
		result.dwY=this.dwY.add(dWeight.dwY);
		
		return result;
	}
	
}

