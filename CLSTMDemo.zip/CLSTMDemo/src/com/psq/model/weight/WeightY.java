package com.psq.model.weight;

import com.psq.model.optimizer.AdamOptimizer;
import com.psq.model.utils.Matrix;

public class WeightY {
	
	public Matrix w,b;
	public AdamOptimizer adamW;
	public AdamOptimizer adamB;
	
	public WeightY(int xDim,int hiddenDim){
		/*
		 * 杩欎釜搴旇淇敼涓�?1锛岃繖涓被涓昏鐢ㄦ潵浣滀负杈撳嚭灞�
		 * 杈撳嚭灞備竴鑸彧鏈変竴涓暟锛屾墍浠ヨ繖閲屽簲璇ヤ慨鏀逛负1
		 */ 
		xDim=1;
		double num2=Math.sqrt(6.0/(xDim+hiddenDim+1));
		this.w=Matrix.uniform(-num2, num2, xDim, hiddenDim);
		this.b=Matrix.uniform(-num2, num2, xDim, 1);
		adamW=new AdamOptimizer(w);
		adamB=new AdamOptimizer(b);
	}
	
	public WeightY(){
		
	}
	
	
	public void update(DWeightY dWeightY, double lr){
		this.w.minusEquals(this.adamW.update(dWeightY.dw).times(lr));
		this.b.minusEquals(this.adamB.update(dWeightY.db).times(lr));
	}
	
	public WeightY clone(){
		WeightY newWeightY=new WeightY();
		newWeightY.w=this.w.copy();
		newWeightY.b=this.b.copy();
		newWeightY.adamW=this.adamW.clone();
		newWeightY.adamB=this.adamB.clone();
		
		return newWeightY;
	}
	
}
