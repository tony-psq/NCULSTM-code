package com.psq.model.weight;



public class Weight {
	/**
	 * ������Ȩ��
	 */
	public WeightHX whxU;
	/**
	 * �����Ȩ��
	 */
	public WeightHX whxO;
	/**
	 * ״̬Ȩ��
	 */
	public WeightHX whxA;
	/** 
	 * yȨ��
	 */
	public WeightY wY;
	
	/**
	 * ���캯����ʼ��
	 * @param xDim
	 * @param hiddenDim
	 */
	public Weight(int xDim, int hiddenDim){
		this.whxU=new WeightHX(xDim, hiddenDim);
		this.whxO=new WeightHX(xDim, hiddenDim);
		this.whxA=new WeightHX(xDim, hiddenDim);
		
		this.wY=new WeightY(1, hiddenDim);
	}
	
	public Weight(){
		
	}
	/**
	 * ����Ȩ�ظ���
	 * @param dWeight
	 * @param lr
	 */
	public void updateHX(DWeight dWeight, double lr){
		this.whxU.update(dWeight.dwhxU, lr);
		this.whxA.update(dWeight.dwhxA, lr);
		this.whxO.update(dWeight.dwhxO, lr);
		
	}
	
	public void updateY(DWeight dWeight, double lr){
		this.wY.update(dWeight.dwY, lr);
	}
	
	public Weight clone(){
		Weight newWeight=new Weight();
		newWeight.whxA=this.whxA.clone();
		newWeight.whxU=this.whxU.clone();
		newWeight.whxO=this.whxO.clone();
		newWeight.wY=this.wY.clone();
		
		return newWeight;
	}
	

}

