package com.psq.model.nLstmNetwork;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import com.psq.model.nLstmState.LstmState;
import com.psq.model.utils.LossFunction;
import com.psq.model.utils.Matrix;
import com.psq.model.utils.MyChart;
import com.psq.model.weight.DWeight;
import com.psq.model.weight.Weight;



public class LstmNetwork {
	/**
	 * 输入层维�?
	 */
	private int xDim;
	/**
	 * 隐藏层维�?
	 */
	private int hiddenDim;
	/** 
	 * 棰勬�?
	 * @param x
	 * @return
	 */
	public Matrix predict(Matrix x){
		LstmState lstmState=this.forward(x);
		int step=x.getRowDimension();
		Matrix preY=new Matrix(step,1);
		for(int i=0;i<step;i++){
			preY.set(i, 0, lstmState.ys[i].get(0, 0));
		}
		return preY;
	}

	/**
	 * 产生权重矩阵
	 * 如下[Whi,Wxi,bi];[Whf,Wxf,bf];[Who,Wxo,bo];[Wha,Wxa,ba];[Wy,by];
	 */
	Weight weight;	
	
	/**
	 * lstm网络
	 * @param xDim 输入层维�?
	 * @param hiddenDim 隐藏层维�?
	 */
	public LstmNetwork(int xDim, int hiddenDim){
		this.xDim=xDim;
		this.hiddenDim=hiddenDim;
		
		//初始化weight
		weight=new Weight(xDim,hiddenDim);
		
	}	
	
	public double train(Matrix x, Matrix y,int batchSize,double lr, int epochs){
		double startTime=System.currentTimeMillis();
		double[] losses=new double[epochs];
		int sampleNum=x.getRowDimension();
		
		Weight weightMinLoss=this.weight;
		double lossMin=Double.POSITIVE_INFINITY;
		
		Matrix xBatch;
		Matrix yBatch;
		
		for(int i=0;i<epochs;i++){
			//大循�?
			Matrix xShuffle=new Matrix(x.getRowDimension(),x.getColumnDimension());
			Matrix yShuffle=new Matrix(y.getRowDimension(),y.getColumnDimension());
			int[] index=shuffleIndex(sampleNum);
			for(int k=0;k<sampleNum;k++){
				xShuffle.setMatrix(k, k, 0, x.getColumnDimension()-1, x.getMatrix(index[k], index[k], 0, x.getColumnDimension()-1));
				yShuffle.setMatrix(k, k, 0, y.getColumnDimension()-1, y.getMatrix(index[k], index[k], 0, y.getColumnDimension()-1));							
			}
			
			// 小循�?
			for(int j=0;j<sampleNum-batchSize+1;j+=batchSize){
				xBatch=xShuffle.getMatrix(j, j+batchSize-1,0, x.getColumnDimension()-1);
				yBatch=yShuffle.getMatrix(j, j+batchSize-1,0, y.getColumnDimension()-1);				
				this.sgdBatch(xBatch, yBatch, lr);				
			}
			
			losses[i]=this.loss(x, y);
			System.out.printf("epoch %d:  loss= %f\n",i,losses[i]);
			if(lossMin>losses[i]){
				lossMin=losses[i];
				weightMinLoss=this.weight.clone();
			}						
		}
		
		this.weight=weightMinLoss;
		System.out.printf("min loss: %f\n", lossMin);
		
		long endTime=System.currentTimeMillis();
		double time=(endTime-startTime)/1000.0;
        System.out.printf("training time: %.2f s\n", time);
        //MyChart.drawLoss(losses);	

        return time;
	}
	
	public Matrix validate(Matrix x, Matrix y){
        
		Matrix preY=this.predict(x);
		double[][] preArray=preY.getArray();
		double[][] yArray=y.getArray();
		MyChart.drawCompare(preArray, yArray);
		
		double[] losses=LossFunction.calLoss(preY, y);
		String[] lossFunctionName=new String[]{"MAE","MSE","RMSE","MAPE","R2"};
		for(int i=0;i<losses.length;i++){
			System.out.println(lossFunctionName[i]+":"+losses[i]);
			//System.out.println(losses[i]);
		}
		//return losses;
		return preY;
		
	}
	
	/**
	 * 涓�涓壒娆′竴涓壒娆″湴鏇存柊鏉冮噸
	 * @param xBatch
	 * @param yBatch
	 * @param lr
	 */
	private void sgdBatch(Matrix xBatch, Matrix yBatch, double lr) {
		// �?个batch走个循环，向前向后传�?
		int step=xBatch.getRowDimension();
		// 进行前向传播
		LstmState lstmState=this.forward(xBatch);
		
		DWeight dWeightSum=this.bptt(xBatch, yBatch, lstmState, step);
		
		/*
		 * 鏈潵鏄簲璇ュ皢涓�涓壒娆＄殑骞冲潎鍊煎拰�?�︿範鐜囦紶鍏ョ殑锛堝綋鐒朵篃鍙互杩欐牱鍋氾級
		 * 浣嗘槸dWeightSum鐨勫钩鍧囬渶瑕佷紶杩涘幓瀵规墍鏈夌殑dw鍙橀噺杩涜骞冲�?
		 * 杩樹笉濡傛妸杩欎釜瑕�?櫎鐨勬暟�?惧湪瀛︿範鐜囦笂锛屽弽姝ｅ悗闈㈡洿鏂版潈閲嶉兘鏄洿鎺ヤ箻鐨�?
		 */
		this.weight.updateHX(dWeightSum, lr/step);
		this.weight.updateY(dWeightSum, lr/step);
		
	}
	/**
	 * 鍓嶅悜浼犳挱
	 * @param x
	 *
	 * @return
	 */
	private LstmState forward(Matrix x){
		int step=x.getRowDimension();
		LstmState lstmState=new LstmState(step,this.xDim,this.hiddenDim);
		for(int t=0;t<step;t++){
			lstmState.update(weight, x.getMatrix(t, t, 0, x.getColumnDimension()-1));			
		}
				
		return lstmState;
				
	}
	
	private DWeight bptt(Matrix x,Matrix y,LstmState lstmState, int step){
		
		DWeight dWeightSum=new DWeight(this.xDim,this.hiddenDim);
		
		Matrix deltaAtNet=new Matrix(this.hiddenDim,1);
		Matrix deltaUtNet=new Matrix(this.hiddenDim,1);
		Matrix deltaOtNet=new Matrix(this.hiddenDim,1);
		
		

		Matrix deltaC=null;
		
		for(int t=step;t>0;t--){
			DWeight dWeight=new DWeight(this.xDim,this.hiddenDim);
			
			Matrix py=lstmState.ys[t-1];
			
			Matrix Y=y.getMatrix(t-1, t-1, 0,0);
			Matrix deltaY=py.minus(Y);//.arrayTimes(Matrix.tanhDerivate(Y));
			
			Matrix h=lstmState.hs[t];
			
			Matrix deltaH=null;
			if(t==step){
				deltaH=weight.wY.w.transpose().times(deltaY.times(Matrix.sigmoidDerivate(py)));
			}else{
				deltaH=weight.wY.w.transpose().times(deltaY.times(Matrix.sigmoidDerivate(py)))
						.plus(weight.whxU.wh.transpose().times(deltaUtNet))
						.plus(weight.whxO.wh.transpose().times(deltaOtNet))
						.plus(weight.whxA.wh.transpose().times(deltaAtNet));
			}
			
			Matrix c=lstmState.cs[t];
			Matrix deltaO=deltaH.arrayTimes(Matrix.tanh(c));
			
			Matrix o=lstmState.os[t];
			Matrix u=lstmState.us[t];

			if(t==step){
				deltaC=deltaH.arrayTimes(o).arrayTimes(Matrix.tanhDerivate(Matrix.tanh(c)));
			}else{
				deltaC=deltaH.arrayTimes(o).arrayTimes(Matrix.tanhDerivate(Matrix.tanh(c)))
						.plus(deltaC.minus(deltaC.arrayTimes(u)));
			}
			
			Matrix a=lstmState.as[t];
			Matrix preC=lstmState.cs[t-1];
			Matrix preH=lstmState.hs[t-1];
			Matrix deltaU=deltaC.arrayTimes(a.minus(preC));
			Matrix deltaA=deltaC.arrayTimes(u);
			
			deltaAtNet=deltaA.arrayTimes(Matrix.tanhDerivate(a));
			deltaUtNet=deltaU.arrayTimes(Matrix.sigmoidDerivate(u));
			deltaOtNet=deltaO.arrayTimes(Matrix.sigmoidDerivate(o));
			
			dWeight.dwY.dw.plusEquals(deltaY.times(Matrix.sigmoidDerivate(py)).times(h.transpose()));
			dWeight.dwY.db.plusEquals(deltaY.times(Matrix.sigmoidDerivate(py)));
			dWeight.update(deltaUtNet, deltaAtNet, deltaOtNet, preH, x.getMatrix(t-1, t-1, 0, x.getColumnDimension()-1));
		
			dWeightSum=dWeightSum.add(dWeight);
		}
		
		return dWeightSum;
		

	}
	
	

	/**
	 * 鎵撲贡绱㈠紩
	 * @param len
	 * @return
	 */
	public int[] shuffleIndex(int len){
		int[] index=new int[len];
		List<Integer> list=new ArrayList<>();
		for(int i=0;i<len;i++){
			list.add(i);
		}
		//Collections.shuffle(list);
		for(int i=0;i<len;i++){
			index[i]=(int)list.get(i);
		}
		
		return index;
		
	}	
	
	/**
	 * 璁＄畻鎹熷け
	 * @param x
	 * @param y
	 * @return
	 */
	public double loss(Matrix x, Matrix y){
		Matrix preY=this.predict(x);				
		double loss=LossFunction.calDoubleMSE(preY, y);
		return loss;
		
	}	
}
